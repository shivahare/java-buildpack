#!/bin/sh
#
#      Copyright (c) 2014 Oracle Corporation, Redwood Shores, CA, USA
#                         All rights reserved.

# ------------------------------------------------------------------------------
# start function definitions

print_usage ()
{
        cat << _EOF_USAGE_
Usage:
    ProvisionApmJavaAsAgent.sh -d <destination>
            [ -h <hostname> ]
            [ -omc-server-url <omc-server-url> -tenant-id <tenant-id> ]
            [ -no-prompt [-overwrite]] [ -no-wallet ] [ -regkey-file <regkey file> ]
            [ -gateway-host <gateway host> -gateway-port <gateway port> [ -additional-gateways <additional gateways> ] ]
            [ -ph <proxy_host> -pp <proxy_port> [ -pt <proxy_auth_token> ]]
            [ -no-cleanup ]  [ -classifications <classifications_string> ]
            [ -v ] [ -debug ] [ -insecure ]

Details:
    -d <destination>
            If you are provisioning an APM Java AS Agent for WebLogic,
            <destination> should be the WebLogic DOMAIN_HOME directory.
            If you are provisioning an APM Java AS Agent for Tomcat,
            <destination> should be the Tomcat CATALINA_HOME directory.
            If you are provisioning an APM Java AS Agent for JBoss or WildFly,
            <destination> should be the JBOSS_HOME directory.
            If you are provisioning an APM Java AS Agent for websphere,
            <destination> should be the Websphere WAS_HOME directory.
            If you are provisioning an APM Java AS Agent for Jetty,
            <destination> should be the JETTY_HOME directory.
            This should be the absolute path of the of DOMAIN_HOME or
            CATALINA_HOME or JBOSS_HOME or WAS_HOME directory. The APM Agent software
            will be installed under this directory.

    -omc-server-url <omc server url>
            Specify the url of the omc server. This parameter is mandatory
            if the agent zip file was not obtained from the omc server.
            This parameter is expected to be in the format https://<host>:<port>

    -tenant-id <tenant id>
            Specify the tenant id. This parameter is mandatory
            if the agent zip file was not obtained from the omc server.

    -h <hostname>  (Optional)
            Specify your AppServer fully qualified hostname.
            By default, this script can determine the machine hostname.
            This can be overridden by specifying this parameter.
            If you want to defer hostname calculation to Agent runtime, you
            can specify empty string for hostname or do-not-use.
            Ex:  -h ""  OR  -h do-not-use

    -no-prompt  (Optional)
            Do not prompt for confirmation -- "Just do it!"
            Normally, this script displays various pieces of information
            that were either supplied to it, or that it derived, and
            then asks the user for permission to proceed with the values.
            When this flag is used, the values will still be displayed,
            but the user will not be prompted before proceeding.
            If APM Java AS Agent already exists in the specified destination,
            the APM Agent will be upgraded automatically.
            When using -no-prompt, use the -regkey-file parameter to
            provide the regsitration key

    -overwrite  (Optional and only works with -no-prompt)
            Deploy APM Agent and overwrite existing APM Agent, if any.

    -regkey-file <regkey file> (Optional)
            Specifies a file that contains a single line with the registration key.
            If this parameter is not used, the script will prompt the user to
            enter the registration key.
            This parameter is mandatory when -no-prompt is used.

    -no-wallet  (Optional)
            Do not use Oracle Wallet even if it exists.
            Normally, this script assumes that the AgentInstall.sh
            script will have laid down an Oracle "auto-login" Wallet
            with the APM Agent's authorization token inside. (This is
            the authorization token that allows the APM Agent to contact
            the various cloud services that it uses.) That wallet will
            then be provisioned as the APM Agent's "credential store".

            However, since not all environments the APM Agent will be
            asked to support have the capability to use an Oracle
            Wallet,
            we must support a way to provision an alternative credential
            store that does not require this. Thus, if the AgentInstall.sh
            script does *not* lay down an Oracle Wallet, the provisioning
            script here will look for the authorization token in the
            properties file that is also laid down by AgentInstall.sh.

            If, however, the "-no-wallet" flag is specified when running
            this provisioning script, it will force the provisioning
            script to *not* use the Oracle Wallet even if one had been
            provided by the AgentInstall.sh script. Instead, the
            APM Agent's authorization token will be gathered from the
            properties file laid down by AgentInstall.sh, and provisioned
            in an alternative (non-Wallet) credential store for the
            APM Agent to use.

    -gateway-host <gateway host> (Optional)
            The gateway host through which the APM java agent communicates
            with the OMC server

    -gateway-port <gateway port> (Optional)
            Gateway port

    -additional-gateways <additional gateways> (Optional)
            Comma separated list of gateway URLs. A valid gateway URL
            is in this format: https://host:port

    -ph <proxy_host>  (Optional)
            Specify your HTTP Proxy Host.
            If the APM Agent must use an HTTP proxy, this is the proxy's
            hostname.

    -pp <proxy_port>  (Optional)
            Specify your HTTP Proxy Port.
            If the APM Agent must use a n HTTPproxy, this is the proxy's
            port.

    -pt <proxy_auth_token>  (Optional)
            Specify the HTTP Proxy Authorization Token to use.
            If the APM Agent must use an HTTP proxy that requires
            authentication, this is the *proxy* authorization token the
            APM Agent will use. It will be added to the APM Agent's
            credential store that gets provisioned here (i.e., either an
            Oracle "auto-login" Wallet or the "alternative" credential
            store if a Wallet is not being used.

    -no-cleanup (Optional)
            Omit the normal clean-up of sensitive data from staging directory.
            Normally, when this script completes, it will remove files that
            potentially hold sensitive data from the staging directory. By
            specifying this option, that clean-up will not be done. This is
            useful when, say, you plan to use the same staging directory to
            provision APM Java AS Agents into multiple WLS domains on the same
            host. Note, however, that on the *last* use of this script, it is
            advisable to *not* use this option, ensuring that sensitive data
            is, in fact, cleaned up.

    -classifications <classifications_string> (Optional)
            Specify a classifications string that will be sent to the OMC server

    -v (Optional)
            Dispaly additional information about user settings

    -debug (Optional)
            Print extended debug information

    -insecure (Optional)
            Use insecure SSL connections during installation, i.e. do not verify the certificates sent by the remote server.
            Be very careful when using this parameter, as it may lead to security vulnerability

Example:
    ./ProvisionApmJavaAsAgent.sh -d /WLS12.1.3/oracle_home/user_projects/domains/acme_domain
    ./ProvisionApmJavaAsAgent.sh -d /Tomcat/apache-tomcat-7.0.62

*** THIS SCRIPT MUST BE RUN FROM THE DIRECTORY WHERE IT LIVES ***

_EOF_USAGE_
}

#locate_java()
{
    _java=$JAVA_BIN
    rm -rf javaerr
    type java 1>/dev/null 2>javaerr
    if [ ! -s javaerr ]; then
        _java=$JAVA_BINjava
    else
        if [ -n "$JAVA_HOME" ] -a [ -x "$JAVA_HOME/bin/java" ];  then
            _java=$JAVA_BIN"$JAVA_HOME/bin/java"
        else
            echo "ERROR: The java executable cannot be found. Add its location to the PATH or set JAVA_HOME"
        fi
    fi
    rm -rf javaerr

    if [ "$_java" != "" ]; then
       javaMajorVersion=`$_java -version 2>&1 | sed -n ';s/.* version "\(.*\)\.\(.*\)\..*"/\1/p;'`
       javaMinorVersion=`$_java -version 2>&1 | sed -n ';s/.* version "\(.*\)\.\(.*\)\..*"/\2/p;'`
       if [ "$javaMajorVersion" -gt "$JAVA_MINIMAL_VERSION_MAJOR" -o "$javaMajorVersion" -eq "$JAVA_MINIMAL_VERSION_MAJOR" -a "$javaMinorVersion" -ge "$JAVA_MINIMAL_VERSION_MINOR" ]; then
           echo `$_java -version 2>&1 | grep version`
       else
            echo "ERROR: The java version is $javaMajorVersion.$javaMinorVersion, while the minimal java version required to run the APM java agent is $JAVA_MINIMAL_VERSION_MAJOR.$JAVA_MINIMAL_VERSION_MINOR"
            _java=$JAVA_BIN
        fi
    fi
}

format_java_version ()
{
    echo $1|sed -n 's/\([0-9]\)\([0-9]*\)/\1.\2/p'
}

# Determine if the DOMAIN is capable of using Oracle Wallet
is_domain_wallet_capable ()
{
    if [ -x "${Domain_Home}/${mkstore_rel_path}" ]; then
        return 1
    fi
    return 0;
}

#Validate gateway URLs, if a gateway is used
validateGatewayUrl()
{
    alcRoot="${gatewayRoot}/emd/gateway/AgentLifeCycle"
    gatewayUrl="${gatewayRoot}/emd/main"
    gatewayParam="HEADER X-Gateway-MetaProtocolVersion REVISION_1"

    if [ "$Tenant_ID" != "" ]; then
        echo INFO: Validating gateway at $gatewayUrl `generateProxyMessage`
        rm -rf ./response.txt
        proxyString=`generateProxyString $gatewayUrl`
        testRunString=`generateTestRunString $testRun`
        certificate=`get_relevant_certificate`
        rc_message=`$_java $proxyString -jar $ApmAgentInstallJar \
            GetContentFromServer \
            $logLevel \
            $gatewayUrl \
            GET \
            ./response.txt \
            $certificate \
            $gatewayParam \
            $testRunString \
            HEADER X-USER-IDENTITY-DOMAIN-NAME $Tenant_ID \
            HEADER X-USER-REGISTRATION_KEY $RegistrationKey `
        if [ "$rc_message" != "OK" ]; then
            echo "ERROR: Unable to connect to the gateway url $gatewayUrl. Ensure the value of GATEWAY_HOST($gatewayHost),GATEWAY_PORT($gatewayPort) are correct and the gateway is up and running."
            exit 1
        fi
        rm -rf ./response.txt

        echo INFO: Validating ALC server at $alcRoot `generateProxyMessage`

        verifyGatewayUrl=$alcRoot/softwaredispatcher/testSvc
        proxyString=`generateProxyString $verifyGatewayUrl`
        certificate=`get_relevant_certificate`
        testRunString=`generateTestRunString $testRun`
        rc_message=`$_java $proxyString -jar $ApmAgentInstallJar \
            GetContentFromServer \
            $logLevel \
            $verifyGatewayUrl \
            GET \
            ./response.txt \
            $certificate \
            $gatewayParam \
            $testRunString \
            HEADER X-USER-IDENTITY-DOMAIN-NAME $Tenant_ID \
            HEADER X-USER-REGISTRATION_KEY $RegistrationKey `
        if [ "$rc_message" != "OK" ]; then
            echo "ERROR: Unable to connect to Agent LCM service through GATEWAY_HOST($gatewayHost),GATEWAY_PORT($gatewayPort).Ensure the Agent Life Cycle service is running."
            exit 1
        fi
        rm -rf ./response.txt
    fi

}

can_create_file ()
{
    file_name=$1
    dir_name=`dirname $file_name`
    if [ -w $dir_name ]; then
        response=1
    else
        response=0
    fi
    echo $response
}

can_read_file ()
{
    file_name=$1
    if [ -r $file_name ]; then
        response=1
    else
        response=0
    fi
    echo $response
}

can_write_file ()
{
    file_name=$1
    if [ -w $file_name ]; then
        response=1
    else
        response=0
    fi
    echo $response
}


get_full_path ()
{
  given_path=$1
  abs_path=""
  #Check if it is absolute path
  case "$1" in
  /*)
        abs_path=$1
        ;;
  *)
      #Check if it is directory and exist
      if [ -d $given_path ]
      then
          abs_path=`cd "$given_path"; pwd -P`
      else
         base_dir=`dirname "$given_path"`
         base_file=`basename "$given_path"`
         path1=`cd "$base_dir"; pwd -P`
         abs_path="$path1/$base_file"
      fi
      ;;
  esac
  echo $abs_path
}

isFilePresent ()
{ 
    file=$1 
    fileProp=$2 
    if [ ! -f $file ] 
    then        
        echo "ERROR: $file [$fileProp] does not exist. Ensure it is present."
        exit 1 
    fi 
}

calcHostName ()
{
    calculated_hostname=
    uname_type=`uname`
    hostname_resolve=$1
    
    if [ "$uname_type" = "" ] 
    then     
        echo "ERROR OS type not available to calculate hostname";
        exit 1;   
    fi   
    
    if [ "$hostname_resolve" = "" ] 
    then     
        echo "ERROR: no hostname provided";
        exit 1;   
    fi   

    if [ "$TEST_DEFAULT_HOSTNAME" != "" ]; then
        if [ "$hostname_resolve" = `echo $hostname_resolve| sed 's/\.[^.]*$//'` ]; then
            calculated_hostname="${hostname_resolve}.com"
        else
            calculated_hostname="${hostname_resolve}"
        fi
    else
        resolver_cmd=""
        if [ "$uname_type" = "AIX" ]
        then
            resolver_cmd="/usr/bin/host"
            isFilePresent $resolver_cmd "host command"
            calculated_hostname=`$resolver_cmd $hostname_resolve | head -1 | awk '{print $1}'`
        elif [ "$uname_type" = "Linux" -o "$uname_type" = "SunOS" ]
        then
            resolver_cmd="/usr/bin/getent"
            isFilePresent $resolver_cmd "getent command"
            calculated_hostname=`$resolver_cmd hosts $hostname_resolve | head -1 | awk '{print $2}'`
        else
            calculated_hostname="";
            echo "WARNING: Cannot resolve hostname: unexpected OS: $uname_type";
            exit 1;
        fi
    fi
    
    if [ "$calculated_hostname" = "" ]
    then
        echo "WARNING: Cannot resolve hostname: Unresolved hostname: $hostname_resolve";
    fi
    
    calculated_hostname=`echo $calculated_hostname | awk '{ print tolower($0) }'`    
}

checkFQDN()
{
    paramName=$1
    paramValue=$2
    if [ "$paramValue" != "" ]
    then
         shortName=`echo $paramValue|cut -d '.' -f1`
         if [ "$shortName" = "$paramValue" ]
         then
            #echo "Error: The $parameterName:$parameterValue is not in the Fully Qualified Domain Name format"
            return 1
         fi
    fi
}

checkFQDNValidity()
{
    parameterName=$1
    parameterValue=$2
    if [ "$parameterValue" != "" ]
    then
        if [ $debug = 1 ]; then
            echo "INFO: Resolving hostname $parameterValue"
        fi
        #this method will compute the name in calculated_hostname variable
        calcHostName $parameterValue
        if [ $debug = 1 ]; then
            echo "INFO: checkFQDNValidity resolved the hostname to ($calculated_hostname)"
        fi
        checkFQDN "$parameterName" $calculated_hostname
        notFQDN=$?

        if [ $notFQDN = 1 -o "$calculated_hostname" = "" ]
        then
            if [ $notFQDN = 1 ]; then
                errMess="ERROR: ${parameterName} '$parameterValue' resolved to '$calculated_hostname' which is not a Fully Qualified Domain Name. \n"
            fi
            if [ "$calculated_hostname" = "" ]; then
                errMess="ERROR: Failed to resolve ${parameterName} '$parameterValue' to a Fully Qualified Domain Name. \n"
            fi
            errMess="${errMess}Please ensure that '/etc/hosts' or Name Server has the required entries to allow the hostname to be resolved to a Fully Qualified Domain Name.\n"
            errMess="${errMess}\n"
            errMess="${errMess}The following is the recommended format of the /etc/hosts file: \n"
            errMess="${errMess}\t<ip> <fully_qualified_host_name> <short_host_name> \n"
            errMess="${errMess}You can also run the below command to verify - \n"
            errMess="${errMess}\tgetent hosts \`hostname\` \n"
            errMess="${errMess}\thost \`hostname\` \n"

            echo -e ${errMess}
            exit 1
        fi
    fi 
}

extractzip (){
    from=$1
    to=$2
    overwrite=$3
    if [ $universal_installer -eq 1 ]; then
        if [ "$overwrite" = "overwrite" ]; then
            param="-o"
        else
            param="-n"
        fi
        unzip $param $from -d $to
    else
        rc_message=`$_java -jar $ApmAgentInstallJar \
                            ExtractZip \
                            $logLevel \
                            $from \
                            $to \
                            $overwrite`

        if [ "$rc_message" != "OK" ]; then
            echo "Extarcting $from into $to ($overwrite) failed!"
        fi
    fi
}

get_gateway_cert (){
    gatewayHostname=$1
    certificateName=$2
    echo INFO: Downloading gateway certificate for host $gatewayHostname `generateProxyMessage`
    rm -rf ./tmp.cer
    getcert_url=$alcRoot/softwaredispatcher/artifact
    proxyString=`generateProxyString $getcert_url`
    testRunString=`generateTestRunString $testRun`
    certificate=`get_relevant_certificate`
    rc_message=`$_java $proxyString -jar $ApmAgentInstallJar \
        GetContentFromServer \
        $logLevel \
        $getcert_url \
        GET \
        ./tmp.cer \
        $certificate \
        PARAM type securitytoken \
        PARAM name agentCert \
        PARAM hostname $gatewayHostname \
        $gatewayParam \
        $testRunString \
        HEADER X-USER-IDENTITY-DOMAIN-NAME $Tenant_ID \
        HEADER X-USER-REGISTRATION_KEY $RegistrationKey `
    if [ "$rc_message" = "OK" ]; then
        echo "INFO: Gateway certificate downloaded succesfully"
        mv ./tmp.cer  $SCRIPT_DIR/certificates/$certificateName
    else
        echo "ERROR: Gateway certificate download failed"
        if [ -r ./tmp.cer ]; then
            rm -rf ./tmp.cer
        fi
        exit 1
    fi
}

get_agent_configuration (){
    echo INFO: Downloading agent configuration for tenant $Tenant_ID from $alcRoot `generateProxyMessage`
    rm -rf ./AgentConfiguration.zip
    getconfig_url=$alcRoot/softwaredispatcher/artifact
    proxyString=`generateProxyString $getconfig_url`
    certificate=`get_relevant_certificate`
    testRunString=`generateTestRunString $testRun`
    rc_message=`$_java $proxyString -jar $ApmAgentInstallJar \
        GetContentFromServer \
        $logLevel \
        $getconfig_url \
        GET \
        ./AgentConfiguration.zip \
        $certificate \
        PARAM type agentconfiguration \
        PARAM name apm \
        $gatewayParam \
        $testRunString \
        HEADER X-USER-IDENTITY-DOMAIN-NAME $Tenant_ID \
        HEADER X-USER-REGISTRATION_KEY $RegistrationKey `
    if [ "$rc_message" = "OK" ]; then
        extractzip $SCRIPT_DIR/AgentConfiguration.zip $SCRIPT_DIR overwrite
        echo "INFO: Agent configuration downloaded successfully"
    else
        echo "ERROR: Agent configuration download failed"
        if [ -r ./AgentConfiguration.zip ]; then
            rm -rf ./AgentConfiguration.zip
        fi
        exit 1
    fi
}

get_relevant_certificate (){
    if [ $insecure -eq 1  ]; then
        certificate=NO-CERTIFICATE
    else
        if [ "$gatewayHost" != "" -a $gatewayCertificatesDownloaded = 0 ]; then
            certificate=NO-CERTIFICATE
        else
            certificate=$SCRIPT_DIR/certificates
        fi
    fi
    echo $certificate
}

get_agent_auth_token (){
    certificate=`get_relevant_certificate`
    getauth_url=$alcRoot/softwaredispatcher/artifact
    proxyString=`generateProxyString $getauth_url`
    testRunString=`generateTestRunString $testRun`
    rc_message=`$_java $proxyString  -jar $ApmAgentInstallJar \
        GetContentFromServer \
        $logLevel \
        $getauth_url \
        GET \
        ./authToken.tmp \
        $certificate \
        PARAM type securitytoken \
        PARAM name agentAuthTokenEncrypted \
        $gatewayParam \
        $testRunString \
        HEADER X-USER-IDENTITY-DOMAIN-NAME $Tenant_ID \
        HEADER X-USER-REGISTRATION_KEY $RegistrationKey`
    if [ "$rc_message" = "ERROR" ]; then
        AgentAuthToken=""
    else
        AgentAuthToken=`cat ./authToken.tmp`
    fi
    rm -f ./authToken.tmp
    echo $AgentAuthToken
}

get_wallet() {
    echo INFO: Downloading agent wallet for tenant $Tenant_ID
    certificate=`get_relevant_certificate`
    getwallet_url=$alcRoot/softwaredispatcher/artifact
    proxyString=`generateProxyString $getwallet_url`
    echo INFO: Downloading agent wallet from $getwallet_url `generateProxyMessage`
    testRunString=`generateTestRunString $testRun`
    rc_message=`$_java $proxyString -jar $ApmAgentInstallJar \
        GetContentFromServer \
        $logLevel \
        $getwallet_url \
        GET \
        ./cwallet.sso \
        $certificate \
        PARAM type securitytoken \
        PARAM name agentAuthWallet \
        $gatewayParam \
        $testRunString \
        HEADER X-USER-IDENTITY-DOMAIN-NAME $Tenant_ID \
        HEADER X-USER-REGISTRATION_KEY $RegistrationKey`
    if [ "$rc_message" = "ERROR" ]; then
        rm -rf cwallet.sso
    fi
}


encrypt_reg_key (){
    rc_message=`$_java -jar $ApmAgentInstallJar \
        Encrypt $logLevel \
        $1 NO-TENANT ./encregkey.tmp`
    if [ "$rc_message" = "ERROR" ]; then
        EncryptedRegistrationKey=""
    else
        EncryptedRegistrationKey=`cat ./encregkey.tmp`
    fi
    rm -f ./encregkey.tmp
    echo $EncryptedRegistrationKey
}

determine_universal_installer (){
    universal_installer=0;
    if [ -r ./ApmAgentBundle.properties ]; then
        universal_installer=1
    fi
    echo $universal_installer
}

setProxyUserPassword() {
    if [ "$ProxyAuthToken" != "" ]; then
        proxyUserPasswordEncoded=`echo $ProxyAuthToken|sed -e 's/Basic //' `
        rc_message=`$_java -jar $ApmAgentInstallJar \
            ConvertFromBase64 $logLevel \
            $proxyUserPasswordEncoded ./proxyUserPassword.tmp`
        if [ "$rc_message" = "ERROR" ]; then
            proxyUserPassword=
        else
            proxyUserPassword=`cat ./proxyUserPassword.tmp`
        fi
        rm -f ./proxyUserPassword.tmp
        if [ "$proxyUserPassword" != "" ]; then
            ProxyUser=`echo $proxyUserPassword | awk -F: '{print $1}'`
            ProxyPassword=`echo $proxyUserPassword | awk -F: '{print $2}'`
        fi
    fi
}

generateProxyString (){
    proxyString=
    if [ "$ProxyHost" != "" ]; then
        proxy_url=$1
        if [ "`echo $proxy_url | cut -c 1-8`" = "https://" ]; then
            protocol="https"
        else
            protocol="http"
        fi
        proxyString="-D${protocol}.proxyHost=${ProxyHost} -D${protocol}.proxyPort=${ProxyPort} "
        if [ "$ProxyUser" != "" ]; then
            proxyString="${proxyString}-D${protocol}.proxyUser=${ProxyUser} -D${protocol}.proxyPassword=${ProxyPassword} "
        fi
    fi
    echo "$proxyString"
}

generateTestRunString (){
    testRunString=
    if [ "$testRun" = "1" ]; then
        testRunString="PARAM testRun Y "
    fi
    echo "$testRunString"
}


generateProxyMessage (){
    proxyMessage=
    if [ "$ProxyHost" != "" ]; then
        proxyMessage="using proxy $ProxyHost:$ProxyPort "
        if [ "$ProxyUser" != "" ]; then
            proxyMessage="$proxyMessage ($ProxyUser/<Password>)"
        fi
    fi

    echo $proxyMessage
}


#####
# Script starts here
#####
echo INFO: Starting APM Java agent installer using the following parameters: $0 $@
SCRIPT_FILE=`get_full_path "$0" `
SCRIPT_DIR=`dirname "$SCRIPT_FILE"`
if [ `pwd -P` != "$SCRIPT_DIR" ]; then
    echo "ERROR: This script must be run from the directory where it lives."
    exit 1
fi

if [ `can_write_file .` = 0 ]; then
    echo "ERROR: No permissions to write on current directory `pwd -P`"
    exit 1
fi

#==================================================================================================
# Initialize some of our variables:
# ---------------------------------
JAVA_MINIMAL_VERSION_MAJOR=1
JAVA_MINIMAL_VERSION_MINOR=6
_java=$JAVA_BIN
Domain_Home="${DESTINATION}"
BundlePropsHostname=
StartupPropsHostname=
InputHostname=
ignoreHostnameFlag="false"
exactHostnameFlag="false"
use_exact_hostname=0
Hostname=
ProxyHost=
ProxyPort=
ProxyAuthToken=
ProxyUser=
ProxyPassword=
ClientCollector_URL=
use_wallet=1
ignore_wallet=0
apmagent_exist=0
do_prompt=1
do_cleanup=1
do_overwrite=0
do_upgrade=0
has_inputhostname=0
has_agentstartup=0
show_all=0
debug=0
mkstore_rel_path=../../../oracle_common/bin/mkstore
agent_version=
#universal_installer=1 indicates that the script is run as a second phase after AgentInstall.sh was run
# In this case, the current directory is the staging directory, agent instllation properties are expected to be
# in AgentBundle.properties, and ApmAgent*.zip exists with the agent binaries
# universal_installer=0 indicates that the user downloaded the agent zip file (e.g. 1.23_APM_226.zip),
# and unzipped it into a temporary directory.
# There are 2 options:
# 1. the agent zip file was downloaded from OMC UI - in this case the agent zip contains AgentConfig.info, a properties file
#    with configuration properties. It also contains the server's certificate and the agent binaries.
# 2. Emailable client - in this case the agent zip file does not contain the agent configuration (i.e., there is no AgentConfig.info.
#    When the installer starts it will download the configuration from tge OMC server

universal_installer=`determine_universal_installer`
RegistrationKey=
regkey_file=
EncryptedRegistrationKey=
alcRoot=
omcServerUrl=
ApmAgentInstallJar=$SCRIPT_DIR/install/libs/ApmAgentInstall.jar
Tenant_ID=
gatewayHost=
gatewayPort=
gatewayProtocol=https
additionalGateways=
gatewayParam=
gatewayCertificatesDownloaded=0
logLevel=INFO
sealed_war=0
classifications=
insecure=0
testRun=0

#==================================================================================================
# Parse command line args:
# ------------------------
if [ "$1" != "" ]; then
    while [ "$1" != "" ]; do
        case $1 in
            -d )    shift
                    Domain_Home=$1
                    ;;
            -omc-server-url )    shift
                    omcServerUrl=$1
                    ;;
            -tenant-id ) shift
                    Tenant_ID=$1
                    ;;
            -h  )   shift
                    InputHostname=$1
                    has_inputhostname=1
                    ;;
            -exact-hostname  )
                    use_exact_hostname=1
                    ;;
            -gateway-host ) shift
                    gatewayHost=$1
                    ;;
            -gateway-port ) shift
                    gatewayPort=$1
                    ;;
            -gateway-protocol ) shift
                    gatewayProtocol=$1
                    ;;
            -additional-gateways ) shift
                    additionalGateways=$1
                    ;;
            -ph )   shift
                    ProxyHost=$1
                    ;;
            -pp )   shift
                    ProxyPort=$1
                    ;;
            -pt )   shift
                    ProxyAuthToken=$1
                    ;;
            -no-wallet ) ignore_wallet=1
                    ;;
            -no-prompt ) do_prompt=0
                    ;;
            -overwrite ) do_overwrite=1
                    ;;
            -no-cleanup ) do_cleanup=0
                    ;;
            -sealed-war ) sealed_war=1
                    ;;
            -force-universal-installer ) universal_installer=1
                    ;;
             -regkey )  shift
                        RegistrationKey=$1
                    ;;
             -regkey-file )  shift
                        regkey_file=$1
                    ;;
             -classifications )  shift
                        classifications=$1
                    ;;
            -v )    show_all=1
                    ;;
            -debug ) debug=1
                    show_all=1
                    logLevel=FINE
                    ;;
            -insecure ) insecure=1
                    ;;
            -testRun ) testRun=1
                    ;;
            -help   ) print_usage
                    exit 0
                    ;;
            * )     echo "ERROR: Unknown parameter: '$1' ... Try '-help' for usage."
                    exit 1
        esac
        shift
    done
else
    echo "ERROR: This script required at least 1 parameter ... Try '-help' for usage."
    exit 1
fi

if [ "$InputHostname" = "do-not-use" ]; then
    InputHostname=
fi

#==================================================================================================
# A bit of error checking:
# ------------------------
errFound=0

#locate_java
if [ "$_java" = "" ]; then
    exit 1
fi

if [ $sealed_war -eq 1  -a  "$Domain_Home" != "" -a ! -d "$Domain_Home" ]; then
    mkdir -p $Domain_Home
    echo INFO: Directory $Domain_Home created
fi



if [ -d "$Domain_Home" ]; then
    Domain_Home=`get_full_path "$Domain_Home" `
else
    echo "ERROR: Destination $Domain_Home is not a directory or does not exist."
    exit 1
fi

if [ `can_write_file $Domain_Home ` = 0 ]; then
    echo "ERROR: Cannot write to destination directory $Domain_Home."
    exit 1
fi



if [ ! -s "${Domain_Home}/startWebLogic.sh" ]; then
    if [ ! -s "${Domain_Home}/bin/catalina.sh" ]; then
        if [ ! -s ${Domain_Home}/bin/jboss-cli.sh ]; then
            if [ ! -s ${Domain_Home}/bin/wasprofile.sh ]; then
                if [ ! -s ${Domain_Home}/bin/jetty.sh ]; then
                    echo "WARNING: ${Domain_Home} does not appear to be the home directory of Weblogic, Tomcat, Jboss, Websphere or Jetty"
                fi
            fi
        fi
    fi
fi

if [ $universal_installer = 0 -a "$RegistrationKey" != "" -a "$regkey_file" != "" ]; then
    echo "WARNING: -regkey and -regkey-file are mutually exclusive. Using the value provided by -regkey"
fi

if [ $universal_installer = 0 -a "$RegistrationKey" = "" -a "$regkey_file" != "" ]; then
    if [ -r $regkey_file ]; then
        RegistrationKey=`cat $regkey_file`
    else
        echo "ERROR: -regkey-file $regkey_file: file does not exist or is not accessible"
        exit 1
    fi
    if [ "$RegistrationKey" = "" ]; then
        echo "ERROR: -regkey-file $regkey_file: file is empty"
        exit 1
    fi

fi

if [  $universal_installer = 0 -a $do_prompt -eq 0 -a "$regkey_file" = "" -a "$RegistrationKey" = "" ]; then
    echo "ERROR: -no-prompt requires the -regkey-file option to be specified too."
    exit 1
fi


while [ $universal_installer = 0 -a "$RegistrationKey" = "" ]
do
    echo "Please enter the registration key or q to quit"
    read RegistrationKey
    if [ "$RegistrationKey" = "q" ]; then
        exit 1
    fi
done

x=`echo $RegistrationKey|grep "[' ,\"]"`
if [ "$x" != "" ]; then
    echo "ERROR: Registration key $RegistrationKey contains illegal characters"
    exit 1
fi

AGENT_ZIP=ApmAgent-*.zip
if [ ! -r $AGENT_ZIP ]; then
    echo "ERROR: The bundled 'ApmAgent-<version>.zip' file is missing or unreadable."
    errFound=1
fi

AGENT_DAT=ApmAgent-*.dat
AGENT_WAR=ApmAgent-*.war
if [ ! -r $AGENT_DAT ]; then
    echo "ERROR: The bundled 'ApmAgent-<version>.dat' file is missing or unreadable."
    errFound=1
fi

if [ $universal_installer -eq 1 ]; then

    if [ ! -r ApmAgentBundle.properties ]; then
        echo "ERROR: The bundled 'ApmAgentBundle.properties' file is missing or unreadable."
        errFound=1
    fi

    if [ ! -r emcs.cer ]; then
        echo "ERROR: The bundled 'emcs.cer' trusted certificate file is missing or unreadable."
        errFound=1
    fi
fi

if [ $universal_installer -eq 0 ]; then

    mkdir -p ./certificates/
    cp ./rootCertificates/* ./certificates/

    #Remove '/' at the end of the url if exists
    omcServerUrl=`echo $omcServerUrl | sed 's:/*$::'`

    if [ ! -r $ApmAgentInstallJar ]; then
        echo "ERROR: The bundled '$ApmAgentInstallJar' file is missing or unreadable."
        errFound=1
    fi

    need_to_download_configuration=0
    if [ "$Tenant_ID" != "" ]; then
        need_to_download_configuration=1
        echo "INFO: Agent configuration will be downloaded from the OMC server or gateway"
        if [ "$gatewayHost" = "" -a "$omcServerUrl" = "" ]; then
            echo "ERROR: -tenant-id requires either -omc-server-url or -gateway-host and -gateway-port to be specified too."
            errFound=1
        fi
        if [ "$gatewayHost" != "" -a "$omcServerUrl" != "" ]; then
            echo "WARNING: Using -omc-server-url when gateway is used is redundant. -omc-server-url value ignored."
        fi
    fi
    if [ "$Tenant_ID" = "" -a "$omcServerUrl" != "" ]; then
        echo "ERROR: -omc-server-url requires -tenant-id to be specified too."
        errFound=1
    fi


    if [ "$need_to_download_configuration" = "0" -a $errFound -eq 0 ]; then

        if [ ! -r AgentConfig.info ]; then
            errFound=1
        fi

        if [ ! -r certificates/emaas.cer ]; then
            errFound=1
        fi

        if [ $errFound -eq 1 ]; then
            echo "ERROR: Agent configuration files are missing: Specify -tenant-id  and either -omc-server-url or gateway parameters to download the configuration."
            exit 1
        fi
        Tenant_ID=`grep '^oracle\.apmaas\.agent\.tenant *=' AgentConfig.info | sed 's/^[^=]*= *//'`
    else
        alcRoot=$omcServerUrl/static/agentlifecycle
    fi
fi

if [ $universal_installer -eq 1 -a ! -r cwallet.sso ]; then
    use_wallet=0
    if [ $ignore_wallet -eq 0 ]; then
        echo "ERROR: The bundled 'cwallet.sso' file is missing or unreadable, and the '-no-wallet' flag was not set."
        echo "       Try rerunning this script with the '-no-wallet' flag."
        errFound=1
    fi
elif [ $ignore_wallet -eq 1 ]; then
    use_wallet=0;
fi

if [ $use_wallet -eq 1 ]; then
    if [ -s "${Domain_Home}/bin/catalina.sh" ]; then
        echo "WARNING: The current destination for provisioning the APM Java AS Agent is TOMCAT. This needs to be done with "no-wallet" option. Hence the installation will be done with no wallet."
        use_wallet=0;
    #---- JBoss 7.0 ----#
    elif [ -s ${Domain_Home}/bin/jboss-cli.sh ]; then
        echo "WARNING: The current destination for provisioning the APM Java AS Agent is JBOSS7 or wildfly. This needs to be done with "no-wallet" option. Hence the installation will be done with no wallet."
        use_wallet=0;
    #---- Websphere ----#
    elif [ -s ${Domain_Home}/bin/wasprofile.sh ]; then
        echo "WARNING: The current destination for provisioning the APM Java AS Agent is Websphere. This needs to be done with "no-wallet" option. Hence the installation will be done with no wallet."
        use_wallet=0;
     #---- Jetty ---- #
    elif [ -s ${Domain_Home}/bin/jetty.sh ]; then
        echo "WARNING: The current destination for provisioning the APM Java AS Agent is Jetty. This needs to be done with "no-wallet" option. Hence the installation will be done with no wallet."
        use_wallet=0;
    fi
fi

if [ $use_wallet -eq 1 ]; then
    if [ -s "${Domain_Home}/startWebLogic.sh" ]; then
        is_domain_wallet_capable
        if [ $? -eq 0 ]; then
            echo "ERROR: You are attempting to use an Oracle Wallet, but your WLS domain does not appear to be capable."
            echo "       Try rerunning this script with the '-no-wallet' option."
            errFound=1
        fi
    else
            echo "ERROR: You are attempting to use an Oracle Wallet, but current destination for provisioning the APM Java AS agent is not WebLogic."
            echo "       Try rerunning this script with the '-no-wallet' option."
            errFound=1
    fi

fi

if [ $do_prompt -eq 1 -a $do_overwrite -eq 1 ]; then
    echo "ERROR: -overwrite requires -no-prompt option to be specified too."
    errFound=1
fi

if [ "$ProxyHost" != "" ]; then
    if [ "$ProxyPort" = "" ]; then
        echo "ERROR: Proxy host (-ph) is set but not proxy port (-pp)."
        missing_var=1
    else
        port_ok=`echo "$ProxyPort" | sed 's/^[0-9][0-9]*$/OK/'`
        if [ "$port_ok" != "OK" ]; then
            echo "ERROR: Proxy port (-pp) is not an integer."
            errFound=1
        fi
    fi
fi

if [ "$ProxyPort" != "" ]; then
    if [ "$ProxyHost" = "" ]; then
        echo "ERROR: Proxy port (-pp) is set but not proxy host (-ph)."
        errFound=1
    fi
fi
if [ "$ProxyAuthToken" != "" ]; then
    if [ "$ProxyHost" = "" -o "$ProxyPort" = "" ]; then
        echo "ERROR: If proxy auth token (-pt) is set, then proxy host (-ph) and proxy port (-pp) must also be set."
        errFound=1
    fi
fi

if [ $errFound = 0 ]; then
    setProxyUserPassword
fi

# establish gatewayRoot based on gatewayHost & gatewayPort
if [ $errFound -eq 0 -a "$gatewayHost" != "" -a "$gatewayPort" != "" ]; then
  gatewayRoot="$gatewayProtocol://$gatewayHost:$gatewayPort"
  #validateGateway url may change alcRoot so it must be called
  # before first access to the alc server
  validateGatewayUrl
fi
# additionalGateways makes sense only when there is a gateway
# i.e., clear additionalGateways when not uploading to a gateway
if [ "$additionalGateways" != "" -a "$gatewayRoot" = "" ]; then
  additionalGateways=
  echo "WARNING: Additional gateways will be ignored since primary gateway was not specified"
fi
#download gateway certificates to the agent's certificates directory:
if [ $universal_installer -eq 0 -a "$gatewayHost" != "" ];then
    UploadRoot=$gatewayRoot
    get_gateway_cert $gatewayHost trustCert_${addGatewayHostname}.cer

    if [ "$additionalGateways" != "" ]; then
      for gateway_url in `echo "$additionalGateways"|sed 's/,/ /g'`
            do
              verified_gateway_url=`echo $gateway_url|grep -Eo 'http[s]?:.*:[0-9]+'`
              if [ "$gateway_url" != "$verified_gateway_url" ]; then
                echo "ERROR: Format of additional gateway $gateway_url is wrong: expected format is https://<host>:<port> (e.g. https://myhost.com:1234)"
                exit 1
              fi

              addGatewayHostname=`echo "$gateway_url"|cut -f2 -d:|sed 's/\///g'`
              get_gateway_cert $addGatewayHostname trustCert_${addGatewayHostname}.cer
              UploadRoot="$UploadRoot,$gateway_url"
            done
    fi
fi
gatewayCertificatesDownloaded=1

if [ $errFound -eq 0 -a $universal_installer -eq 0 -a "$need_to_download_configuration" = "1" ]; then
    get_agent_configuration
    if [ ! -r AgentConfiguration.zip ]; then
        echo "ERROR: Agent configuration was not downloaded succesfully: 'AgentConfiguration.zip' file is missing or unreadable"
        errFound=1
    else
        if [ ! -r AgentConfig.info ]; then
            echo "ERROR: Agent configuration was not downloaded succesfully: 'AgentConfig.info' file is missing or unreadable"
            errFound=1
        else
            if [ ! -r $ApmAgentInstallJar ]; then
                echo "ERROR: Agent configuration was not downloaded succesfully: '$ApmAgentInstallJar' file is missing or unreadable."
                errFound=1
            else
                if [ ! -r certificates/emaas.cer ]; then
                    echo "ERROR: Agent configuration was not downloaded succesfully: 'certificates/emaas.cer' trusted certificate file is missing or unreadable."
                    errFound=1
                fi
            fi
        fi
    fi
fi

if [ $errFound -ne 0 ]; then
    exit 1
fi

agent_version=`echo $AGENT_ZIP | sed 's/ApmAgent-//' | sed 's/.zip//'`
if [ $universal_installer -eq 1 ]; then
    #==================================================================================================
    # Look at the downloaded ApmAgentBundle.properties file for some of our variable settings:
    # ----------------------------------------------------------------------------------------
    Tenant_ID=`grep '^Tenant_ID *=' ApmAgentBundle.properties | sed 's/^[^=]*= *//'`
    if [ "$UploadRoot" = "" ]; then
        UploadRoot=`grep '^UploadRoot *=' ApmAgentBundle.properties | sed 's/^[^=]*= *//' | sed 's,/$,,'`
    fi
    CollectorRoot=`grep '^ApmCollectorRoot *=' ApmAgentBundle.properties | sed 's/^[^=]*= *//' | sed 's,/$,,'`
    EncryptedRegistrationKey=`grep '^RegistrationKey *=' ApmAgentBundle.properties | sed 's/^[^=]*= *//'`
    AgentAuthToken=`grep '^AgentAuthToken *=' ApmAgentBundle.properties | sed 's/^[^=]*= *//'`
    BundlePropsHostname=`grep '^ORACLE_HOSTNAME *=' ApmAgentBundle.properties | sed 's/^[^=]*= *//'`
else
    #==================================================================================================
    # Look at the downloaded AgentConfig.info file for some of our variable settings:
    # ----------------------------------------------------------------------------------------
    Tenant_ID=`grep '^oracle\.apmaas\.agent\.tenant *=' AgentConfig.info | sed 's/^[^=]*= *//'`
    if [ "$UploadRoot" = "" ]; then
        UploadRoot=`grep '^oracle\.apmaas\.agent\.uploadRoot *=' AgentConfig.info | sed 's/^[^=]*= *//' | sed 's,/$,,'`
    fi
    CollectorRoot=`grep '^oracle\.apmaas\.agent\.collectorRoot *=' AgentConfig.info | sed 's/^[^=]*= *//' | sed 's,/$,,'`
    if [ "$alcRoot" = "" ] ; then
        #alcRoot might not be empty when we are using gateways
        alcRoot=`grep '^oracle\.apmaas\.agent\.alcRoot *=' AgentConfig.info | sed 's/^[^=]*= *//'`
    fi
fi

#==================================================================================================
# Determine hostname from multiple sources with different options
# 1) Find AgentStartup hostname
# 2) Find Bundle hostname. If not exist, resolve it locally
# 3) Choose the hostname
# 4) Resolve the hostname. If selected hostname is not the same as resolved hostname, fail it with explanation.
#    Skip this step if -exact-hostname argument is used.
# ----------------------------------------------------------------------------------------

if [ -r "$Domain_Home"/apmagent/config/AgentStartup.properties ]; then
    StartupPropsHostname=`grep '^oracle.apmaas.agent.hostname *=' "$Domain_Home"/apmagent/config/AgentStartup.properties | sed 's/^[^=]*= *//' | sed 's,/$,,'`
    ignoreHostnameFlag=`grep '^oracle.apmaas.agent.ignore.hostname *=' "$Domain_Home"/apmagent/config/AgentStartup.properties | sed 's/^[^=]*= *//' | sed 's,/$,,'`
    exactHostnameFlag=`grep '^oracle.apmaas.agent.exact.hostname *=' "$Domain_Home"/apmagent/config/AgentStartup.properties | sed 's/^[^=]*= *//' | sed 's,/$,,'`
    has_agentstartup=1

    if [ "$ignoreHostnameFlag" = "" ]; then
        ignoreHostnameFlag="false"
    fi
    if [ "$exactHostnameFlag" = "" ]; then
        exactHostnameFlag="false"
    fi
fi

# If there is input hostname, ignore bundle hostname
if [ $has_inputhostname -eq 0 ]; then
    # If bundle hostname does not exist, resolve it locally.
    if [ "$BundlePropsHostname" = "" -o "$Hostname" = "@AGENT_HOSTNAME@" ]; then
        if [ $universal_installer -eq 1 ]; then
            echo "*** Warning: ApmAgentBundle.properties does not have ORACLE_HOSTNAME property."
        fi
        if [ "$TEST_DEFAULT_HOSTNAME" = "" ]; then
            calcHostName `hostname`
        else
            calcHostName $TEST_DEFAULT_HOSTNAME
        fi
        BundlePropsHostname=$calculated_hostname
    fi
fi

if [ "$BundlePropsHostname" != "" ]; then
    BundlePropsHostname=`echo $BundlePropsHostname | awk '{ print tolower($0) }'`
fi

if [ $has_inputhostname = 1 ]; then
    ignoreHostnameFlag="true"
fi
if [ $use_exact_hostname = 1 ]; then
    exactHostnameFlag="true"
fi

Hostname=
if [ $has_inputhostname = 1 ]; then
    Hostname=$InputHostname
elif [ $do_overwrite = 1 ]; then
    Hostname=$BundlePropsHostname
elif [ $do_prompt = 0 ]; then
    if [ $has_inputhostname = 1 ]; then
        Hostname=$InputHostname
    elif [ $has_agentstartup = 1 ]; then
        Hostname=$StartupPropsHostname
    else
        Hostname=$BundlePropsHostname
    fi
elif [ $has_agentstartup != 1 -a "$StartupPropsHostname" = "" ]; then
    Hostname=$BundlePropsHostname
elif [ "$BundlePropsHostname" = "$StartupPropsHostname" ]; then
    Hostname=$BundlePropsHostname
else
    while true; do
        echo ""
        echo "Please choose a hostname for APM Agent or 'Q' to quit"
        if [ "$StartupPropsHostname" != "" ]; then
            echo "1: $StartupPropsHostname (hostname defined in existing APM Agent) "
        else
            echo "1: Do not use host (as defined in existing APM Agent) "
        fi
        echo "2: $BundlePropsHostname"
        echo "Q: Quit"
        echo "Enter [1, 2 ,Q]: "
        read hostOption
        case $hostOption in
            [1]* )
                Hostname=$StartupPropsHostname
                break
            ;;
            [2]* )
                Hostname=$BundlePropsHostname
                break
            ;;
            [Qq]* )
                exit 2
            ;;
            * )
            ;;
        esac
    done
fi
Hostname=`echo $Hostname | awk '{ print tolower($0) }'`

if [ "$Hostname" != "" -a $use_exact_hostname = 0 ]; then

    # Resolve hostname
    # If hostname is not resolvable or not equal to resolved hostname, print error message and quit
    calcHostName $Hostname
    _Hostname=$calculated_hostname
    if [ "$Hostname" != "$_Hostname" ]; then
        echo ""
        echo "ERROR: Specified hostname does not match resolved hostname."
        echo "  Specified Hostname = $Hostname"
        if [ "$_Hostname" = "" ]; then
            _Hostname="<unresolvable>"
        fi
        echo "  Resolved Hostname  = $_Hostname"
        echo "Please check if there is any typo in hostname. If you are sure the hostname is correct,"
        echo "please add ' -exact-hostname ' argument to ProvisionApmJavaAsAgent command."
        exit 1
    fi

    # Perform FQDN check
    # If resolved hostname is not FQDN, print error message and quit
    checkFQDN "hostname" $_Hostname
    if [ $? = 1 ]; then
        echo ""
        echo "ERROR: Failed to resolve hostname to a fully qualified hostname. "
        echo "  Specified Hostname = $Hostname "
        if [ "$_Hostname" == "" ]; then
            _Hostname="<unresolvable>"
        fi
        echo "  Resolved Hostname  = $_Hostname"
        echo "Ways to address:  "
        echo "1) If you are sure the hostname is correct or intented to use non-fully qualified hostname, "
        echo "   please add ' -exact-hostname ' argument to ProvisionApmJavaAsAgent command. "
        echo "2) If resolved hostname is not fully qualified hostname, "
        echo "   please ensure /etc/hosts file has the following recommended format: "
        echo "       <ip> <fully_qualified_host_name> <short_host_name> "
        echo "3) If you want to use fully qualified hostname without updating /etc/hosts file, "
        echo "   please add ' -h <fully_qualified_host_name> -exact-hostname ' argument "
        echo "   to ProvisionApmJavaAsAgent command."
        exit 1
    fi
fi

#---------------------------------------------------------------------------------------------------
# Find the injectionType
InjectionType=""
if [ -r "$Domain_Home"/apmagent/config/AgentStartup.properties ]; then
        InjectionType=`grep '^oracle.apmaas.agent.browser.injectionType *=' "$Domain_Home"/apmagent/config/AgentStartup.properties | sed 's/^[^=]*= *//' | sed 's,/$,,'`
fi

# Find the EnableBrowserAgent,  convert to all lowercases
EnableBrowserAgent=""
if [ -r "$Domain_Home"/apmagent/config/AgentStartup.properties ]; then
        EnableBrowserAgent=`grep '^oracle.apmaas.agent.enableBrowserAgent *=' "$Domain_Home"/apmagent/config/AgentStartup.properties | sed 's/^[^=]*= *//' | sed 's,/$,,'`
fi
EnableBrowserAgent=`echo $EnableBrowserAgent | awk '{ print tolower($0) }'`

#Get the wallet
#If we are using the universal installer, AgentInstall.sh downlods the wallet file
#However, if we use simplified installer, we will need to download the wallet here, if it should be used
if [ $universal_installer -eq 0 -a $use_wallet -eq 1 ]; then
    get_wallet
    if [ ! -r cwallet.sso ]; then
        echo "ERROR: Could not download the Oracle Wallet."
        echo "       Try rerunning this script with the '-no-wallet' option."
        exit 1
    fi
fi


#==================================================================================================
# Hard code these guys:
# ---------------------
Trusted_Cert_Path="./"
if [ $universal_installer -eq 0 ]; then
    Trusted_Cert_Path="${Trusted_Cert_Path}certificates/"
fi

if [ $use_wallet -eq 1 ]; then
    Agent_Cred_Store_Path=agentWallet
else
    Agent_Cred_Store_Path=AgentHttpBasic.properties
fi


if [ $universal_installer = 0 ]; then
    echo INFO: Retrieving agent authorization token
    AgentAuthToken=`get_agent_auth_token`
    if [ "$AgentAuthToken" = "" ]; then
        echo "ERROR: Cannot retrieve authorization token."
        exit 1
    fi

    EncryptedRegistrationKey=`encrypt_reg_key $RegistrationKey`
    if [ "$EncryptedRegistrationKey" = "" ]; then
        echo "ERROR: Cannot encrypt registration key."
        exit 1
    fi
    echo INFO: Agent authorization token retrieved succesfully
fi




# = = = = = = = = = = = = = = = = = = = =  (READY TO START)  = = = = = = = = = = = = = = = = = = = =


#---------------------------------------------------------------------------------------------------
# Show user what their variables are set to:
echo "*************************************************************************"
if [ $universal_installer -eq 1 ]; then
    echo "INFO: Running second phase of the universal installer"
else
    echo "INFO: Running APM java agent installer"
fi
echo " "
echo "Your settings are as follows:"
echo " "
echo "              Agent Version = $agent_version"
echo "                  Tenant_ID = $Tenant_ID"
if [ "$Hostname" != "" ]; then
    if [ $use_exact_hostname = 1 ]; then
        echo "                   Hostname = $Hostname (use exact hostname)"
    else
        echo "                   Hostname = $Hostname"
    fi
else
    echo "               Hostname = <provision agent without a hostname>"
fi
echo "                Destination = $Domain_Home"
if [ $universal_installer = 0 ]; then
    echo "            RegistrationKey = $RegistrationKey"
else
    echo "  Encrypted RegistrationKey = $EncryptedRegistrationKey"
fi
if [ "$ProxyHost" != "" ]; then
    echo "                  ProxyHost = $ProxyHost"
    echo "                  ProxyPort = $ProxyPort"
    if [ "$ProxyAuthToken" != "" ]; then
        echo "             ProxyAuthToken = $ProxyAuthToken"
    fi
fi
if [ "$gatewayHost" != "" ]; then
    echo "               Gateway Host = $gatewayHost"
    echo "               Gateway Port = $gatewayPort"
    if [ "$additionalGateways" != "" ]; then
        echo "        Additional Gateways = $additionalGateways"
    fi
fi

if [ "$EnableBrowserAgent" != "" ]; then
    echo "         EnableBrowserAgent = $EnableBrowserAgent"
fi

if [ "$classifications" != "" ]; then
    echo "            Classifications = $classifications"
fi

echo " "
if [ $show_all -gt 0 ]; then
    echo "Also in use (derived or bundled):"
    echo "          Trusted_Cert_Path = $Trusted_Cert_Path"
    echo "      Agent_Cred_Store_Path = $Agent_Cred_Store_Path"
    if [ $use_wallet -eq 0 ]; then
        echo "             AgentAuthToken = $AgentAuthToken"
    fi
    echo " "
fi

#---------------------------------------------------------------------------------------------------
# All of the non-optional variables must be set to something in order to proceed:
missing_var=0
if [ "$Tenant_ID" = "" ]; then
    echo "ERROR: Tenant_ID is not set."
    missing_var=1
fi
if [ "$Domain_Home" = "" ]; then
    echo "ERROR: Domain_Home is not set."
    missing_var=1
fi
if [ "$EncryptedRegistrationKey" = "" ]; then
    echo "ERROR: RegistrationKey is not set."
    missing_var=1
fi
if [ $use_wallet -eq 0 -a "$AgentAuthToken" = "" ]; then
    echo "ERROR: Not using a Wallet, yet AgentAuthToken is not set."
    missing_var=1
fi
if [ "$Trusted_Cert_Path" = "" ]; then
    echo "ERROR: Trusted_Cert_Path is not set."
    missing_var=1
fi
if [ "$Agent_Cred_Store_Path" = "" ]; then
    echo "ERROR: Agent_Cred_Store_Path is not set."
    missing_var=1
fi
if [ "$UploadRoot" = "" ]; then
    echo "ERROR: UploadRoot is not set."
    missing_var=1
fi
if [ "$CollectorRoot" = "" ]; then
    echo "ERROR: ApmCollectorRoot is not set."
    missing_var=1
fi

if [ $missing_var -ne 0 ]; then
    exit 1
fi

#---------------------------------------------------------------------------------------------------
# Do some sanity checks on the required variables:

if [ ! -d "$Domain_Home" ]; then
    echo "ERROR: Destination (Domain_Home/Catalina_home) is not a directory."
    exit 1
fi

if [ ! -w "$Domain_Home" ]; then
    echo "ERROR: Destination (Domain_Home/Catalina_home) points to a directory that is not writable."
    exit 1
fi

#---------------------------------------------------------------------------------------------------
# If prompting, ask permission to proceed with the current values:
if [ $do_prompt -eq 1 ]; then
    while true; do
	echo "Do you wish to proceed with these values? (y/n) "
        read yn
        case $yn in
            [Yy]* ) break;;
            [Nn]* ) exit 2;;
            * ) echo "Please answer yes or no.";;
        esac
    done
fi

# If prompting, ask permission to proceed with overwrite or upgrade
if [ -d "$Domain_Home/apmagent" ]; then
    apmagent_exist=1
    if [ $do_prompt -eq 1 ]; then
        echo ""
        echo "It appears an APM Java AS Agent is already provisioned under Destination."
        while true; do
            echo "Do you wish to Overwrite[o], Upgrade[u], or Quit[q] "
            read ouq
            case $ouq in
            [Oo]* )
                do_overwrite=1
                do_upgrade=0
                break
                ;;
            [Uu]* )
                do_overwrite=0
                do_upgrade=1
                break
                ;;
            [Qq]* )
                exit 2
                ;;
            * ) ;;
            esac
        done
    else
        if [ $do_overwrite -eq 1 ]; then
            do_overwrite=1
            do_upgrade=0
        else
            do_overwrite=0
            do_upgrade=1
        fi
    fi
else
    do_overwrite=1
    do_upgrade=0
fi

if [ $do_overwrite -eq 1 ]; then
    ignoreHostnameFlag="true"
    if [ $use_exact_hostname = 1 ]; then
        exactHostnameFlag="true"
    else
        exactHostnameFlag="false"
    fi
fi

# Set default value of injectionType
# If overwrites, default value of injectionType is correlation
# If upgrades, default value of injectionType is reference
defaultInjectionType=""
if [ $do_overwrite -eq 1 ]; then
    InjectionType="correlation"
    EnableBrowserAgent=""
else
    if [ $do_upgrade -eq 1 ]; then
        defaultInjectionType="reference"
    fi
fi

if [ "$InjectionType" = "" ]; then
    echo "INFO: set injectionType=$defaultInjectionType by default"
    InjectionType=$defaultInjectionType
fi

#---------------------------------------------------------------------------------------------------
# Prepare new install or upgrade
# Unpackage the APM Agent bits, resulting in the ./apmagent directory under your $Domain_Home.
cd "$Domain_Home"
if [ $do_overwrite -eq 1 ]; then
    echo "INFO: Performing new installation"
    rm -rf ./apmagent
    extractzip $SCRIPT_DIR/$AGENT_ZIP $Domain_Home overwrite
else
    if [ $do_upgrade -eq 1 ]; then
        echo "INFO: Performing upgrade"
        rm -rf ./apmagent/lib.backup
        rm -rf ./apmagent/config.backup
        if [ `can_create_file ./apmagent/lib.backup` = 0 -o `can_create_file ./apmagent/config.backup` = 0 ]; then
            echo "ERROR: Not enough permissions to create backup directories `get_full_path ./apmagent/lib.backup` and `get_full_path ./apmagent/config.backup`"
            exit 1
        fi
        if [ `can_read_file "$Domain_Home"/apmagent/config/AgentStartup.properties` -eq 0 ]; then
            echo "ERROR: Properties file "$Domain_Home"/apmagent/config/AgentStartup.properties does not exist or cannot be read"
            exit 1
        fi
        if [ -e "$Domain_Home"/apmagent/config/AgentHttpBasic.properties ]; then
            if [ `can_read_file "$Domain_Home"/apmagent/config/AgentHttpBasic.properties` -eq 0 ]; then
                echo "ERROR: Not enough permissions to read properties file "$Domain_Home"/apmagent/config/AgentHttpBasic.properties"
                exit 1
            fi
        fi
        mv -f ./apmagent/lib ./apmagent/lib.backup
        mv -f ./apmagent/config ./apmagent/config.backup
        cp -rf ./apmagent/config.backup/ ./apmagent/config/
        rm -rf ./apmagent/config/agentWallet
        rm -rf ./apmagent/config/certificates
        extractzip $SCRIPT_DIR/$AGENT_ZIP $Domain_Home no-overwrite
    fi
fi


#---------------------------------------------------------------------------------------------------
# Prepare working AgentStartup.properties.work and remove mandatory properties, so it can be used for merging.
if [ `can_create_file "$Domain_Home"/apmagent/config/AgentStartup.properties.work` -eq 0 ]; then
    echo "ERROR: Not enough permissions to create work files in "$Domain_Home"/apmagent/config"
    exit 1
fi
cd "$Domain_Home"/apmagent/config
mv -f AgentStartup.properties AgentStartup.properties.work
mv -f AgentHttpBasic.properties AgentHttpBasic.properties.work

sed '/^ *$/d' AgentStartup.properties.work > AgentStartup.properties.temp
mv -f AgentStartup.properties.temp AgentStartup.properties.work
sed '/oracle.apmaas.agent.tenant *=/d' AgentStartup.properties.work > AgentStartup.properties.temp
mv -f AgentStartup.properties.temp AgentStartup.properties.work
sed '/oracle.apmaas.agent.hostname *=/d' AgentStartup.properties.work > AgentStartup.properties.temp
mv -f AgentStartup.properties.temp AgentStartup.properties.work
sed '/oracle.apmaas.agent.exact.hostname *=/d' AgentStartup.properties.work > AgentStartup.properties.temp
mv -f AgentStartup.properties.temp AgentStartup.properties.work
sed '/oracle.apmaas.agent.ignore.hostname *=/d' AgentStartup.properties.work > AgentStartup.properties.temp
mv -f AgentStartup.properties.temp AgentStartup.properties.work
sed '/oracle.apmaas.agent.uploadRoot *=/d' AgentStartup.properties.work > AgentStartup.properties.temp
mv -f AgentStartup.properties.temp AgentStartup.properties.work
sed '/oracle.apmaas.agent.collectorRoot *=/d' AgentStartup.properties.work > AgentStartup.properties.temp
mv -f AgentStartup.properties.temp AgentStartup.properties.work
sed '/oracle.apmaas.common.registrationKey *=/d' AgentStartup.properties.work > AgentStartup.properties.temp
mv -f AgentStartup.properties.temp AgentStartup.properties.work
sed '/oracle.apmaas.common.pathToCertificate *=/d' AgentStartup.properties.work > AgentStartup.properties.temp
mv -f AgentStartup.properties.temp AgentStartup.properties.work
sed '/oracle.apmaas.common.pathToCredentials *=/d' AgentStartup.properties.work > AgentStartup.properties.temp
mv -f AgentStartup.properties.temp AgentStartup.properties.work
sed '/oracle.apmaas.agent.registryServiceUrl *=/d' AgentStartup.properties.work > AgentStartup.properties.temp
mv -f AgentStartup.properties.temp AgentStartup.properties.work
if [ "$EnableBrowserAgent" != "" ]; then
    sed '/oracle.apmaas.agent.enableBrowserAgent *=/d' AgentStartup.properties.work > AgentStartup.properties.temp
    mv -f AgentStartup.properties.temp AgentStartup.properties.work
fi
sed '/oracle.apmaas.agent.browser.injectionType *=/d' AgentStartup.properties.work > AgentStartup.properties.temp
mv -f AgentStartup.properties.temp AgentStartup.properties.work
if [ "$ProxyHost" != "" ]; then
    sed '/oracle.apmaas.common.proxyHost *=/d' AgentStartup.properties.work > AgentStartup.properties.temp
    mv -f AgentStartup.properties.temp AgentStartup.properties.work
    sed '/oracle.apmaas.common.proxyPort *=/d' AgentStartup.properties.work > AgentStartup.properties.temp
    mv -f AgentStartup.properties.temp AgentStartup.properties.work
fi
if [ "$ClientCollector_URL" != "" ]; then
    sed '/oracle.apmaas.agent.collectorUrl *=/d' AgentStartup.properties.work > AgentStartup.properties.temp
    mv -f AgentStartup.properties.temp AgentStartup.properties.work
fi
if [ "$classifications" != "" ]; then
    sed '/oracle.apmaas.agent.appServer.classifications *=/d' AgentStartup.properties.work > AgentStartup.properties.temp
    mv -f AgentStartup.properties.temp AgentStartup.properties.work
fi

#---------------------------------------------------------------------------------------------------
# Copy the EMCS trusted certificate to the agent's certificates directory:
cd "$Domain_Home"/apmagent/config
mkdir -p $Trusted_Cert_Path
if [ $universal_installer -eq 1 ];then
    cp -r "$SCRIPT_DIR"/*.cer $Trusted_Cert_Path
else
    cp -r "$SCRIPT_DIR"/certificates/*.cer $Trusted_Cert_Path/
fi

#---------------------------------------------------------------------------------------------------
# Create AgentStartup.properties with mandatory data provided by the provisioner for this instance:
cd "$Domain_Home"/apmagent/config
echo "oracle.apmaas.agent.tenant = $Tenant_ID" >> AgentStartup.properties
if [ "$Hostname" != "" ]; then
    echo "oracle.apmaas.agent.hostname = $Hostname" >> AgentStartup.properties
    echo "oracle.apmaas.agent.exact.hostname = $exactHostnameFlag" >> AgentStartup.properties
fi
echo "oracle.apmaas.agent.ignore.hostname = $ignoreHostnameFlag" >> AgentStartup.properties
echo "oracle.apmaas.agent.uploadRoot = $UploadRoot" >> AgentStartup.properties
echo "oracle.apmaas.agent.collectorRoot = $CollectorRoot" >> AgentStartup.properties
if [ "$EnableBrowserAgent" != "" ]; then
    echo "oracle.apmaas.agent.enableBrowserAgent = $EnableBrowserAgent" >> AgentStartup.properties
fi
echo "oracle.apmaas.agent.browser.injectionType = $InjectionType" >> AgentStartup.properties
echo "oracle.apmaas.common.registrationKey = $EncryptedRegistrationKey" >> AgentStartup.properties
echo "oracle.apmaas.common.pathToCertificate = $Trusted_Cert_Path" >> AgentStartup.properties
echo "oracle.apmaas.common.pathToCredentials = $Agent_Cred_Store_Path" >> AgentStartup.properties
if [ "$ProxyHost" != "" ]; then
    echo "oracle.apmaas.common.proxyHost = $ProxyHost" >> AgentStartup.properties
    echo "oracle.apmaas.common.proxyPort = $ProxyPort" >> AgentStartup.properties
fi
if [ "$ClientCollector_URL" != "" ]; then
    echo "oracle.apmaas.agent.collectorUrl = $ClientCollector_URL" >> AgentStartup.properties
fi
if [ "$classifications" != "" ]; then
    echo "oracle.apmaas.agent.appServer.classifications = $classifications" >> AgentStartup.properties
fi

# merge backedup properties to AgentStartup.properties
cat AgentStartup.properties.work >> AgentStartup.properties

# remove work bits
rm -f AgentStartup.properties.work
rm -f AgentHttpBasic.properties.work

#---------------------------------------------------------------------------------------------------
# Handle the credential store for the Agent ... either a wallet, or the alternative store:
cd "$Domain_Home"/apmagent/config
if [ $use_wallet -eq 1 ]; then
    #-----------------------------------------------------------------------------------------------
    # Using an Oracle Wallet ...
    # Create the wallet directory, copy the wallet file into it, add the lock file, and set proper
    # permissions on all. Then, if also using a proxy auth token, try to add that to the wallet:
    rm -f AgentHttpBasic.properties
    mkdir -m 700 -p ./agentWallet
    cp "$SCRIPT_DIR"/cwallet.sso ./agentWallet
    touch ./agentWallet/cwallet.sso.lck
    chmod 600 ./agentWallet/*
    if [ "$ProxyAuthToken" != "" ]; then
        if [ "`echo $ProxyAuthToken | cut -c 1-6`" != "Basic " ]; then
            ProxyAuthToken="Basic $ProxyAuthToken"
        fi
        . "${Domain_Home}"/bin/setDomainEnv.sh
        cd "${Domain_Home}"/apmagent/config
        "${Domain_Home}/${mkstore_rel_path}" -wrl ./agentWallet -createCredential proxyService proxyAuthToken "$ProxyAuthToken"
    fi
else
    #-----------------------------------------------------------------------------------------------
    # Not using an Oracle Wallet ...
    # The alternative credential store is the AgentHttpBasic.properties file. Rename the origial
    # AgentHttpBasic.properties as a backup copy, then recreate the file with data provided by the
    # provisioner for this instance:
    rm -f AgentHttpBasic.properties
    echo "oracle.apmaas.agent.http.token = $AgentAuthToken" >> AgentHttpBasic.properties
    if [ "$ProxyAuthToken" != "" ]; then
        if [ "`echo $ProxyAuthToken | cut -c 1-6`" != "Basic " ]; then
            ProxyAuthToken="Basic $ProxyAuthToken"
        fi
        echo "oracle.apmaas.agent.http.proxy.token = $ProxyAuthToken" >> AgentHttpBasic.properties
    fi
fi

cd "$SCRIPT_DIR"
# Generating a sealed agent war file if needed: Put the updated configuratuion files in the war
if [ $sealed_war -eq 1 ];then
    for file in ApmAgent*.dat; do
       cp "$file" "`basename "$file" .dat`.war"
    done
    agent_war_file=`ls -r $AGENT_WAR | head -1`
    mkdir -p ./WEB-INF/config
    mkdir -p ./WEB-INF/lib
    cp -r "${Domain_Home}"/apmagent/config/* ./WEB-INF/config
    if [ $has_inputhostname = 0 ]; then
        cd ./WEB-INF/config
        rm -f AgentStartup.properties.temp
        sed '/oracle.apmaas.agent.hostname/d' AgentStartup.properties > AgentStartup.properties.temp
        mv -f AgentStartup.properties.temp AgentStartup.properties

        cd "$SCRIPT_DIR"
    fi
    cp -r "${Domain_Home}"/apmagent/lib/* ./WEB-INF/lib
    zip -ur "$SCRIPT_DIR/$agent_war_file" WEB-INF
    echo INFO: Created sealed war file at $SCRIPT_DIR/$agent_war_file
    rm -rf WEB-INF
fi

#---------------------------------------------------------------------
# if the -no-cleanup flag is not set , clean up the staging directory
if [ $do_cleanup -eq 1 ]; then
    rm -rf "$SCRIPT_DIR"/cwallet.sso
    rm -rf "$SCRIPT_DIR"/ApmAgentBundle.properties
fi

cd "$SCRIPT_DIR"

if [ $apmagent_exist -eq 0 -a $sealed_war -eq 0 ]; then
# One last thing to do ... here, we just give directions to the provisioner on what they must 
# manually do to modify their DOMAIN's startWebLogic.sh script, then stop and restart their WLS:
cat << _EOF_INSTALL_
*******************************************************************************
So far, so good! Now, one more thing to do, which you will perform manually.
You will need to modify your destination's start up script so that
the APM instrumentation you have just laid down and configured will be invoked.

Here's what you do:


Weblogic :
---------

1. Make a backup copy of your startWebLogic.sh file:
        % cd \$DOMAIN_HOME/bin
        % cp startWebLogic.sh startWebLogic.sh.orig

2. Now edit the script with your favorite text editor (e.g. "vi"), and add the 
   -javaagent option to the set of JAVA_OPTIONS found therein, by adding the 
   following line right after the "setDomainEnv.sh" call:
   
        JAVA_OPTIONS="\${JAVA_OPTIONS} -javaagent:\${DOMAIN_HOME}/apmagent/lib/system/ApmAgentInstrumentation.jar"

3. Stop and restart your WebLogic Application Server. Note that you will use
   the \$DOMAIN_HOME/bin version of stopWebLogic.sh, but the \$DOMAIN_HOME
   version of startWebLogic.sh, even though you edited the \$DOMAIN_HOME/bin
   version. The "upper" level one will, in fact, invoke the "lower" level one:

        % cd \$DOMAIN_HOME/bin
        % ./stopWebLogic.sh                        
        % cd ..                                    
        % nohup ./startWebLogic.sh >& startup.log &

4. Finally, if you have any Managed WebLogic Application Servers, stop and 
   restart them also:

        % cd \$DOMAIN_HOME/bin
        % ./stopManagedWebLogic.sh {SERVER_NAME} {ADMIN_URL} {USER_NAME} {PASSWORD}                                                  
        % nohup ./startManagedWebLogic.sh {SERVER_NAME} {ADMIN_URL} >& {SERVER_NAME}.log &

Tomcat :
-------

1. Make a backup copy of your Catalina.sh file:
            % cd "\$CATALINA_HOME/bin"
            % cp catalina.sh catalina.sh.orig

2. Now edit the script with your favorite text editor (e.g. "vi") , and add the
   -javaagent option to the set of CATALINA_OPTS, by adding the
   following line:

    	 CATALINA_OPTS="\${CATALINA_OPTS} -javaagent:\"\${CATALINA_HOME}/apmagent/lib/system/ApmAgentInstrumentation.jar\""

3. Stop and restart your Tomcat Server.

        % cd "\$CATALINA_HOME/bin"
        % ./shutdown.sh
        % ./startup.sh

JBoss/Wildfly (Standalone Mode) :
--------------------------------

1. Make a backup copy of your standalone.conf file:
        % cd \$JBOSS_HOME/bin
        % cp standalone.conf standalone.conf.orig

2. Now edit standalone.conf with your favorite text editor (e.g. "vi"),

        1) search text 'JBOSS_MODULES_SYSTEM_PKGS', add "oracle.apmaas.agent,oracle.apmaas.repackaged" to it.

        If it was JBOSS_MODULES_SYSTEM_PKGS="org.jboss.byteman" then, the new value will be JBOSS_MODULES_SYSTEM_PKGS="org.jboss.byteman,oracle.apmaas.agent,oracle.apmaas.repackaged"
 
        2) go to the end of the file and add following line

        JAVA_OPTS="\$JAVA_OPTS -javaagent:<JBOSS_HOME>/apmagent/lib/system/ApmAgentInstrumentation.jar"

3. Stop and restart your JBoss/Wildfly Server
    		

JBoss/Wildfly (Domain Mode) :
----------------------------

1. Make a backup copy of your domain.conf file:
        % cd \$JBOSS_HOME/bin
        % cp domain.conf domain.conf.orig

2. Now edit domain.conf with your favorite text editor (e.g. "vi"), and search text 'JBOSS_MODULES_SYSTEM_PKGS'

        Add "oracle.apmaas.agent,oracle.apmaas.repackaged" to it.
 
        If it was JBOSS_MODULES_SYSTEM_PKGS="org.jboss.byteman" then, the new value will be JBOSS_MODULES_SYSTEM_PKGS="org.jboss.byteman,oracle.apmaas.agent,oracle.apmaas.repackaged"

3. Edit \$JBOSS_HOME/domain/configuration/host.xml, search text '<jvms>', add following option into its '<jvm-options>':

        <option value="-javaagent:<JBOSS_HOME>/apmagent/lib/system/ApmAgentInstrumentation.jar"/>

4. Stop and restart your JBoss/Wildfly Server


Websphere :
----------

1. From websphere admin console, click on Servers tab and  select the server on which you want to provision the APM Agent. Expand Java and Process Management tab and select Process Definition. Select Java Virtual Machine under Additional Properties tab.

2. In Generic JVM arguments field, add the following line: 
	-javaagent:\$WAS_HOME/apmagent/lib/system/ApmAgentInstrumentation.jar -Dws.ext.dirs=\$WAS_HOME/apmagent/lib/agent/ApmEumFilter.jar

3. Create a backup of \$WAS_HOME/properties/server.policy file 
    	% cd \$WAS_HOME/properties 
	% cp server.policy server.policy.orig

4. Add the following snippet in \$WAS_HOME/properties/server.policy to grant permission to apmagent directory. 
 
        grant codeBase "file:\$WAS_HOME/apmagent/-" 
        { 
        permission java.security.AllPermission; 
        }; 

5. Restart the websphere server

Jetty :
------

1. Make a backup copy of your jetty.sh file:
            % cd "\$JETTY_HOME/bin"
            % cp jetty.sh jetty.sh.orig

2. Now edit the script with your favorite text editor (e.g. "vi") , and add the -javaagent option to the set of JAVA_OPTIONS, by adding the
   following line:

         JAVA_OPTIONS="\${JAVA_OPTIONS} -javaagent:\${JETTY_HOME}/apmagent/lib/system/ApmAgentInstrumentation.jar"

3. Stop and restart your Jetty Server. Make sure you set JETTY_HOME in environment

        % cd "\$JETTY_HOME/bin"
        % ./jetty.sh stop
        % ./jetty.sh start

*******************************************************************************
_EOF_INSTALL_

else

    if [ $sealed_war -eq 1 ]; then
cat << _EOF_WAR_
*******************************************************************************
So far, so good! Now, you can now deploy $SCRIPT_DIR/$agent_war_file in your application server

*******************************************************************************
_EOF_WAR_
    else
cat << _EOF_UPGRADE_
*******************************************************************************
So far, so good! Now, you can restart your application server in the following location:

    ${Domain_Home}

*******************************************************************************
_EOF_UPGRADE_
fi
fi
